import UnderConstruction from "@/shared/ui/underConstruction";

const Gradepage = () => {
  return <UnderConstruction />;
};

export default Gradepage;

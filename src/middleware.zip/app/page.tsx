export default function Home(): React.JSX.Element {
  return (
    <div>
      <h1 className="text-3xl font-bold underline">Hello world!</h1>
      <h1>Hello, developers</h1>
    </div>
  );
}

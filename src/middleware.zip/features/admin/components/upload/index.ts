export { default as AvatarUpload } from "./partials/avatarUpload";
export { default as CvUpload } from "./partials/cvUpload";
export { default as DuiUpload } from "./partials/duiUpload";
